arr = [5, 10, 2, 3, 18, 8]
x = int(input("Enter number: "))


def search(arr, x):
    for i in range(len(arr)):
        if arr[i] == x:
            print(arr.index(x))
            return i
        
    return -1

search(arr, x)